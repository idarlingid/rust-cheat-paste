#pragma once
namespace Value {
	namespace WeaponName {
		const char* Sniper[]{
			"L96 Rifle",
			"Bolt Action Rifle",
		};

		const char* Automatic[]{
			"M249",
			"Assault Rifle",
			"LR-300 Assault Riffle",
			"MP5A4",
			"Thompson",
			"Custom SMG",
		};

		const char* SemiAutomatic[]{
			// PISTOLS
			"Python Revolver",
			"Revolver",
			"M92 Pistol",
			"Semi-Automatic Pistol",
			"Nailgun",
			"Eoka Pistol",

			// SHOTGUNS
			"Waterpipe Shotgun",
			"Double Barrel Shotgun",
			"Pump Shotgun",
			"Spas-12 Shotgun",


			// RIFLE
			"M39 Rifle",
			"Semi-Automatic Rifle",

			"Multiple Grenade Launcher"

		};

		const char* Bow[]{
			"Crossbow",
			"Hunting Bow",
			"Compound Bow",
		};
	}
	namespace bools {
		namespace Aim {
			bool Enable, VisibleCheck, IgnoreTeam, TargetLine, Fov, Smooth, IgnoreSleepers;
		}
		namespace Player {
			bool CustomFov;
			namespace PlayerWalk {
				bool Spiderman, FakeAdmin, ChangeGravity, InfinityJump, AntiAim;
			}
			namespace PlayerModel {
			}
		}

		namespace Visuals {
			namespace PlayerPanel {
				bool Enable, Name, HP, Weapons;
			}
			namespace ESP {
				bool Enable, Player, NPC, IgnoreSleeper, Corpse, Backpack;
				bool Name, Box, Distance, SteamID, Health, Weapon;
			}
			namespace World {
				namespace Items {
					bool Stash, Hemp, AirDrop, CH47, Minicopter, Patrol;
					namespace Ore {
						bool Stone, Iron, Sulfur;
					}
				}
				bool AlwaysDay;
			}
			namespace Radar {
				bool Enable, Sleeper;
			}
		}
		namespace Misc {

		}
		namespace Weapon {
			bool IsAutomatic, NoSpread, NoRecoil, ThickBullet;
		}
	}
	namespace floats {
		namespace Aim {
			int Distance = 400;
			int Fov = 50;
			float Smooth = 5;
		}
		namespace Screen {
			float H;
			float W;
		}
		namespace Player {
			float CustomFov = 90;
			float Gravity = 2;
		}
		namespace Visuals {
			namespace World {
				int LimitDistance = 100;
				int LimitDistance2 = 2000;
				int Time = 9;
			}
			namespace Radar {
				int Radius = 100;
				int Distance = 100;
			}
		}
	}
	namespace Colors {
		namespace Aim {
			float Fov[] = { 0.7, 0.7, 0.7, 1 };
			float TargetLine[] = { 0.7, 0.7, 0.7, 1 };
		}
		namespace Visuals {
			namespace ESP {
				float Weapon[] = { 0.7, 0.7, 0.7, 1 };
				float Box[] = { 0.7, 0.7, 0.7, 1 };
				float Name[] = { 0.7, 0.7, 0.7, 1 };
				float Health[] = { 0.7, 0.7, 0.7, 1 };
				float Distance[] = { 0.7, 0.7, 0.7, 1 };
			}
			namespace World {
				float Stash[] = { 0, 0.25 , 1, 1 };
				float Hemp[] = { 0, 1 , 0, 1 };
				float AirDrop[] = { 0.4, 0 ,1, 1 };
				float CH47[] = { 1, 0 , 0, 1 };
				float Minicopter[] = { 0.45, 1 ,0, 1 };
				float Patrol[] = { 0, 1 ,1, 1 };
				float Corpse[] = { 0.45, 1 ,0, 1 };
				float Backpack[] = { 0, 1 ,1, 1 };
				namespace Ore {
					float Stone[] = { 0.86, 0.86 , 0.86, 1 };
					float Iron[] = { 1, 0.58 ,0, 1 };
					float Sulfur[] = { 1, 1 , 0, 1 };
				}
			}
		}
	}
}