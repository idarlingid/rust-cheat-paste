#pragma once
void Jopa()
{

	HANDLE hMutex = (OpenMutexA)(MUTEX_ALL_ACCESS, 0, cry("CVhnljfxUvddaNk67f6v9t9BHQU9Qr3nZZQWRm2AClp6Bwu8"));
	HANDLE hMutex1 = (OpenMutexA)(MUTEX_ALL_ACCESS, 0, cry("CVhnIjfUtxUvddaNk67RREGRGU9Qr3nZZWQRm2AClp6Bwu8"));
	HANDLE hMutex2 = (OpenMutexA)(MUTEX_ALL_ACCESS, 0, cry("CVhnIjfUtxUvddFGDSFGsNk67fRREGRU9Qr3mZZQWRm2AClp8"));

	if (!hMutex, !hMutex1, !hMutex2)
	{
		raise(13);

	}

}
