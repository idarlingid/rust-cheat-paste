#pragma once
void WeaponFix(BaseProjectile* weapon);
void Misc(UINT64 TodCycle)
{
	if (Value::bools::Visuals::World::AlwaysDay)
		safe_write(TodCycle + 0x10, Value::floats::Visuals::World::Time, float);

	if (Value::bools::Player::PlayerWalk::Spiderman)
		LocalPlayer.BasePlayer->SpiderMan();

	if (Value::bools::Player::PlayerWalk::FakeAdmin)
		LocalPlayer.BasePlayer->FakeAdmin();

	if (Value::bools::Player::PlayerWalk::ChangeGravity)
		LocalPlayer.BasePlayer->GravituMod();

	if (Value::bools::Player::PlayerWalk::InfinityJump)
		LocalPlayer.BasePlayer->InfinityJump();

	if (Value::bools::Player::CustomFov)
		LocalPlayer.BasePlayer->SetFov();

	if (Value::bools::Player::PlayerWalk::AntiAim)
		LocalPlayer.BasePlayer->AntiAim();

	int WeaponId = 0;
	int last = -1;
	auto* active = LocalPlayer.BasePlayer->GetActiveWeapon();
	if (active) {
		if (active->GetUID() != 0)
		{
			if (WeaponId != active->GetItemID())
			{
				WeaponId = active->GetItemID();
			}
			last = active->GetUID();
			if (last)
			{
				WeaponFix(active);
			}
		}
		else if (!last)
			last = active->GetUID();
	}
}